import Lenis from 'lenis';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

function formatDMS(value: number) {
  const deg = Math.floor(value);
  const minFloat = (value - deg) * 60;
  const min = Math.floor(minFloat);
  const sec = Math.floor((minFloat - min) * 60);
  return `${deg}° ${String(min).padStart(2, '0')}' ${String(sec).padStart(2, '0')}"`;
}

function initAnimations() {
  // Reveal sections
  document.querySelectorAll<HTMLElement>('.reveal-fx').forEach((el) => {
    gsap.fromTo(
      el,
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 1.2,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: el,
          start: 'top 85%',
          toggleActions: 'play none none reverse',
        },
      }
    );
  });

  // Parallax images
  document.querySelectorAll<HTMLElement>('.parallax-img').forEach((img) => {
    gsap.to(img, {
      y: '20%',
      ease: 'none',
      scrollTrigger: {
        trigger: img.parentElement ?? undefined,
        start: 'top bottom',
        end: 'bottom top',
        scrub: true,
      },
    });
  });
}

function initCursorAndCoords() {
  const cursor = document.querySelector<HTMLElement>('.cursor-cross');
  const gps = document.getElementById('gps-coords') as HTMLElement | null;

  // base ~ Toscana (come demo), variazioni piccole
  const baseLat = 43 + 31 / 60 + 36 / 3600;
  const baseLng = 10 + 40 / 60 + 54 / 3600;
  const maxDelta = 0.006; // ~20-25 arcsec

  let lastX = 0;
  let lastY = 0;
  let scheduled = false;

  function updateGpsFromCursor() {
    scheduled = false;
    if (!gps) return;

    const nx = window.innerWidth ? lastX / window.innerWidth : 0.5;
    const ny = window.innerHeight ? lastY / window.innerHeight : 0.5;

    const lat = baseLat + (0.5 - ny) * maxDelta;
    const lng = baseLng + (nx - 0.5) * maxDelta;

    gps.textContent = `${formatDMS(lat)} N  ${formatDMS(lng)} E`;
  }

  document.addEventListener('mousemove', (e) => {
    if (cursor) {
      cursor.style.left = `${e.clientX}px`;
      cursor.style.top = `${e.clientY}px`;
    }

    lastX = e.clientX;
    lastY = e.clientY;

    if (!scheduled) {
      scheduled = true;
      requestAnimationFrame(updateGpsFromCursor);
    }
  });
}

export function initSite() {
  // Initialize Lenis
  const lenis = new Lenis({ duration: 1.2, smoothWheel: true });

  function raf(time: number) {
    lenis.raf(time);
    requestAnimationFrame(raf);
  }

  function start() {
    lenis.start();

    // Show GPS coords (if present)
    const gps = document.getElementById('gps-coords') as HTMLElement | null;
    if (gps) gps.style.opacity = '1';

    requestAnimationFrame(raf);
    initAnimations();
    initCursorAndCoords();
  }

  // Preloader Logic (solo se presente)
  window.addEventListener('load', () => {
    const preloader = document.getElementById('preloader');
    if (!preloader) {
      start();
      return;
    }

    // Blocca scroll e Lenis durante il preloader
    lenis.stop();
    document.body.style.overflow = 'hidden';

    setTimeout(() => {
      preloader.classList.add('hidden');
      document.body.style.overflow = 'auto';
      start();
    }, 3500);
  });
}

// Auto-init
initSite();


